/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java HarpString
 * 
 * This program creates a visual representation of the sound of the harp
 * strings from HarpString.java
 * 
 */

public class VisualHarp {
    private static String NOTE_MAPPING = 
        "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' ";
    private static double concertA = 440.0;
    private static double radius = 0.25;
    
    private static void draw(int index) {
        PennDraw.setPenRadius(0.01);
        double pointY = 0.45 + (Math.random() * 0.1);
        double pointX = 0.13 + index * 0.02;
        int rgb = 50 + 5 * index;
        PennDraw.setPenColor(rgb, rgb, rgb);
        PennDraw.enableAnimation(100);
        for (int i = 5; i > 0; i--) {
            PennDraw.circle(pointX, pointY, 0.05 + 0.01 * i);
            PennDraw.advance();
            PennDraw.clear();
        }
        
    }
    
    public static void main(String[] args) {
        // create a set of harp strings
        HarpString[] harpStrings = new HarpString[NOTE_MAPPING.length()];
        for (int i = 0; i < NOTE_MAPPING.length(); i++) {
            harpStrings[i] = new HarpString(
                 concertA * Math.pow(2.0, (i - 24.0) / 12.0));
        }
        
        // declare variables
        int index;
        char key;

        // infinite loop to check if a key is pressed
        // and play the associated note
        while (true) {
            // check if the user has typed a key; if so, process it   
            if (PennDraw.hasNextKeyTyped()) {
                key = PennDraw.nextKeyTyped(); // which key was pressed?
                index = NOTE_MAPPING.indexOf(key);
                if (index == -1) {
                    continue;
                }
                harpStrings[NOTE_MAPPING.indexOf(key)].pluck();
                // animation
                draw(index);
            }
            
            // compute the combined sound of all harp strings
            double sample = 0.0;
            for (int i = 0; i < NOTE_MAPPING.length(); i++) {
                sample += harpStrings[i].sample();
            }
            
            // play sound
            StdAudio.play(sample);
            
            // advance the simulation of each harp string by one step
            for (int i = 0; i < NOTE_MAPPING.length(); i++) {
                harpStrings[i].tic();
            }
        }
    }
}
