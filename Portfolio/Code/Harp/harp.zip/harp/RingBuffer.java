/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java RingBuffer
 * 
 * This creates a ring buffer data structure that will be used to
 * simuluate a harp string.
 * 
 */

public class RingBuffer {
    private double[] bufferArray; // items in the buffer
    private int first;            // index for the next dequeue or peek
    private int last;             // index for the next enqueue
    private int currentSize;      // number of items in the buffer

    // create an empty buffer with a max capacity
    // input: how many items the RingBuffer can take in
    public RingBuffer(int capacity) {
        bufferArray = new double[capacity];
    }

    // return how many items are currently in the buffer
    public int currentSize() {
        return currentSize();
    }

    // check if the buffer array is 0 (size is 0)
    public boolean isEmpty() {
        if (currentSize == 0) {
            return true;
        } else {
            return false;
        }
    }

    // is the buffer full (size equals array capacity)?
    public boolean isFull() {
        if (currentSize == bufferArray.length) {
            return true;
        } else {
            return false;
        }
    }

    // add item x to the end of the buffer
    // input: double x to be added
    public void enqueue(double x) {
        if (isFull()) {
            throw new RuntimeException("ERROR: Attempting to enqueue " +
                                       "to a full buffer.");
        }
        bufferArray[last] = x;
        last++;
        last = last % bufferArray.length;
        currentSize++;
    }

    // delete and return item at the front of the buffer
    public double dequeue() {
        if (isEmpty()) {
            throw new RuntimeException("ERROR: Attempting to dequeue " +
                                       "from an empty buffer.");
        }
        double x = bufferArray[first];
        bufferArray[first] = 0.0;
        first++;
        currentSize--;
        first = first % bufferArray.length;
        // System.out.println("Dequeued: " + x);
        return x;
    }

    // return (but do not delete) item at the front
    public double peek() {
        if (isEmpty()) {
            throw new RuntimeException("ERROR: Attempting to peek " +
                                       "at an empty buffer.");
        }
        
        // System.out.println("Peek: " + bufferArray[first]);
        return bufferArray[first];
    }

    // print the contents of the RingBuffer object for debugging
    private void printBufferContents() {
        // print out first, last, and currentSize
        System.out.println("first:        " + first);
        System.out.println("last:         " + last);
        System.out.println("currentSize:  " + currentSize);
        System.out.println("Empty? : " + isEmpty());
        System.out.println("Full ? : " + isFull());
        
        // print bufferArray's length and contents if it is not null
        // otherwise just print a message that it is null
        if (bufferArray != null) {
            System.out.println("array length: " + bufferArray.length);
            System.out.println("Buffer Contents:");
            for (int i = 0; i < bufferArray.length; i++) {
                System.out.println(bufferArray[i]);
            }
        } else {
            System.out.println("bufferArray is null");
        }
    }

    // a simple test of the constructor and methods in RingBuffer
    public static void main(String[] args) {
        // create a RingBuffer with bufferSize elements
        // where bufferSize is a command-line argument
        int bufferSize = Integer.parseInt(args[0]);
        RingBuffer buffer = new RingBuffer(bufferSize);
        
        buffer.printBufferContents();
        
        /** Test Cases:
         * buffer.enqueue(5.4);
         * buffer.enqueue(6.7);
         * buffer.enqueue(5.3);
         * buffer.enqueue(4.3);
         * buffer.peek();
         * buffer.enqueue(2.1);
         * buffer.printBufferContents();
         * buffer.dequeue();
         * buffer.dequeue();
         * buffer.peek();
         * buffer.enqueue(7.9);
         * buffer.printBufferContents();
         * buffer.dequeue();
         * buffer.dequeue();
         * buffer.enqueue(0.1);
         * buffer.peek();
         * buffer.printBufferContents();
         * buffer.dequeue();
         * buffer.peek();
         * buffer.enqueue(9.31);
         * buffer.enqueue(5.75);
         * buffer.dequeue();
         * buffer.dequeue();
         * buffer.printBufferContents();
         */
    }

}
