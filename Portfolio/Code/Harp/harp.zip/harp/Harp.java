/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java Harp
 * 
 * This uses the ring buffer and Karplus-Strong algorithm implemented in
 * RingBuffer and HarpString to simulate a harp with the keys of the
 * keyboard. 
 * 
 */

public class Harp {
    private static String NOTE_MAPPING = 
        "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' "; 
    // keys that make up the keyboard
    private static double concertA = 440.0; // frequency of concert A
    
    public static void main(String[] args) {
        // create a set of harp strings
        HarpString[] harpStrings = new HarpString[NOTE_MAPPING.length()];
        for (int i = 0; i < NOTE_MAPPING.length(); i++) {
            harpStrings[i] = new HarpString(
                  concertA * Math.pow(2.0, (i - 24.0) / 12.0));
        }

        // infinite loop to check if a key is pressed
        // and play the associated note
        while (true) {
            // check if the user has typed a key; if so, process it   
            if (PennDraw.hasNextKeyTyped()) {
                char key = PennDraw.nextKeyTyped(); // which key was pressed?
                if (NOTE_MAPPING.indexOf(key) == -1) {
                    continue;
                }
                harpStrings[NOTE_MAPPING.indexOf(key)].pluck();
                
                // System.out.println(NOTE_MAPPING.indexOf(key);
            }
            
            // compute the combined sound of all harp strings
            double sample = 0.0;
            for (int i = 0; i < NOTE_MAPPING.length(); i++) {
                sample += harpStrings[i].sample();
            }
            // System.out,println(sample); 
            
            // play the sample on standard audio
            StdAudio.play(sample);
  
            // advance the simulation of each harp string by one step   
            for (int i = 0; i < NOTE_MAPPING.length(); i++) {
                harpStrings[i].tic();
            }
        }
    }
}