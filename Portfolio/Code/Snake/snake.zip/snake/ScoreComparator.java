/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java ScoreComparator
 * 
 * This file creates a comparator for a Score object that
 * compares Scores based on their numerical component.
 * 
 */

import java.util.Comparator;

public class ScoreComparator implements Comparator<Score> {
    
    // sorts in descending order
    public int compare(Score s1, Score s2) {
        return s2.getScore() - s1.getScore();
    }
}