/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java HighScores
 * 
 * This program creates a HighScore list containing the top
 * five scores in the game. 
 * 
 */

// import declarations
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class HighScores implements HighScoresInterface {
    List<Score> scores; // create a list of scores
    
    // creates an "empty" list (names are xx, scores are 0) of highscores
    public HighScores() {
        scores = new ArrayList<Score>();
        In inStream = new In("scores.txt");
        for (int i = 0; i < 5; i++) { // add five blank highscores
            String name = inStream.readString();
            int score = inStream.readInt();
            scores.add(new Score(name, score));
        }
    }
    
    /** Adds a score to the list of highscores if the score is 
     *  a new high score (within the top five scores in the game)
     * Parameters: name (String) and highscore (int) to be added 
     *             to the highscore list
     * Side Effects: adds score to highscore list
     * Return: void
     */
    public void addScore(String name, int newScore) {
        // compare new score to scores already in the high score list
        for (Score score : scores) { 
            // add the new score to the list if it is greater than scores
            // already in the list
            if (newScore > score.getScore()) { 
                scores.add(new Score(name, newScore)); 
                Collections.sort(scores, new ScoreComparator()); // sort list
                scores.remove(5); // remove the lowest score from the list
                break; // exit loop after adding score
            }
        }
    }
    
    /** Returns the score in each HighScore to be printed
     * Parameters: index i where the score is located
     * Return: String representation of the score with leading 0's
     */
    public String printScore(int i) {
        String score = "";
        if (scores.get(i).getScore() < 10) {
            score += "000" + scores.get(i).getScore();
        } else if (scores.get(i).getScore() < 100) {
            score += "00" + scores.get(i).getScore();
        } else if (scores.get(i).getScore() < 1000) {
            score += "0" + scores.get(i).getScore();
        } else {
            score += scores.get(i).getScore();
        }
        return score;
    }
    
    /** Returns the name in each HighScore to be printed
     * Parameters: index i where the name is located
     * Return: String containing initials
     */
    public String printName(int i) {
        return scores.get(i).getName();
    }
    
    /** TEST CASES: 
      * public static void main(String[] args) {
      *     HighScores scores = new HighScores();
      *     scores.addScore("EL", 5);
      *     scores.addScore("JA", 7);
      *     scores.addScore("JS", 3);
      *     scores.addScore("MW", 27);
      *     scores.addScore("TY", 30);
      *     scores.addScore("KL", 6);
      *     for (int i = 0; i < 5; i++) {
      *         System.out.println(scores.printName(i) + "\t" + 
      *                            scores.printScore(i));
      *     }
      * }
      */
}
