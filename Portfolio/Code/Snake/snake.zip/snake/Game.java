/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java Game
 * 
 * This program is a version of the classic game of Snake, in
 * which a snake controlled by the user's keyboard is navigated 
 * around the screen to eat a series of bits. The user loses if
 * the snake crashes into itself or the edge of the screen.
 * This file contains the graphical interface of the game and 
 * should be run for the user to play. 
 * 
 */

public class Game {
    private static Snake snake; // declares a snake
    private static boolean play; // check if the game is playing
    private static boolean end; // check if the game has ended
    private static Bit food; // "food" bits for snake to consume
    private static HighScores scores; // declares a highscores table
    private static String user; // String containing user input name
    
    /** Draws snake continuously moving right
     * Parameters: none
     * Side Effects: moves snake to the right and draws updated position
     * Return: void
     */
    private static void snakeRight() {
        while (true) {
            if (PennDraw.hasNextKeyTyped()) { // checks for next key typed
                char move = PennDraw.nextKeyTyped();
                if (move == 'w') { 
                    snakeUp(); // move up if 'w' is typed
                    return;
                } else if (move == 's') { 
                    snakeDown(); // move down if 's' is typed
                    return;
                }
            }
            if (hit()) {
                return; // stop moving if snake hits something
            } else {
                snake.moveRight(); // continuously move right
                if (snake.eat(food)) {
                    snake.generateFood(); // generate new food if food is eaten
                }
                PennDraw.advance(); // advance animation
                PennDraw.clear(0, 0, 0);
                gameStart();
            }
        }
    }
    
    /** Draws snake continuosly moving up
     * Parameters: none
     * Side Effects: moves snake up and draws updated position
     * Return: void
     */
    private static void snakeUp() {
        while (true) {
            if (PennDraw.hasNextKeyTyped()) { // checks for next key typed
                char move = PennDraw.nextKeyTyped();
                if (move == 'a') {
                    snakeLeft(); // move left if 'a' is typed
                    return;
                } else if (move == 'd') {
                    snakeRight(); // move right if 'd' is typed
                    return;
                }
            }
            if (hit()) {
                return; // stop moving if snake hits something
            } else {
                snake.moveUp(); // continuously move up
                if (snake.eat(food)) {
                    snake.generateFood(); // generate new food if food is eaten
                }
                PennDraw.advance(); // advance animation
                PennDraw.clear(0, 0, 0);
                gameStart();
            }
        }
    }
    
    /** Draws snake continuously moving left
     * Parameters: none
     * Side Effects: moves snake to the left and draws position
     * Return: void
     */
    private static void snakeLeft() {
        while (true) {
            if (PennDraw.hasNextKeyTyped()) { // checks for next key typed
                char move = PennDraw.nextKeyTyped();
                if (move == 'w') {
                    snakeUp(); // move up if 'w' is typed
                    return;
                } else if (move == 's') {
                    snakeDown(); // move down if 's' is typed
                    return;
                }
            }
            if (hit()) {
                return; // stop moving if snake hits something
            } else {
                snake.moveLeft(); // continuously move left
                if (snake.eat(food)) {
                    snake.generateFood(); // generate new food if food is eaten
                }
                PennDraw.advance(); // advance animation
                PennDraw.clear(0, 0, 0);
                gameStart();
            }
        }
    }
    
    /** Draws snake continuosly moving down
     * Parameters: none
     * Side Effects: moves snake down and draws position
     * Return: void
     */
    private static void snakeDown() {
        while (true) {
            if (PennDraw.hasNextKeyTyped()) { // checks for next key typed
                char move = PennDraw.nextKeyTyped();
                if (move == 'a') {
                    snakeLeft(); // move left if 'a' is typed
                    return;
                } else if (move == 'd') {
                    snakeRight(); // move right if 'd' is typed
                    return;
                }
            }
            if (hit()) {
                return; // stop moving if snake hits something
            } else {
                snake.moveDown(); // continuously move down
                if (snake.eat(food)) {
                    snake.generateFood(); // generate new food if food is eaten
                }
                PennDraw.advance(); // advance animation
                PennDraw.clear(0, 0, 0);
                gameStart();
            }
        }
    }
    
    /** Checks if snake hits itself or the walls
     * Parameters: none
     * Side Effects: sound effect plays, snake dies (becomes red), 
     *               end screen appears
     * Return: boolean (true if hit)
     */
    private static boolean hit() {
        if (snake.getHeadX() < 4 || snake.getHeadX() > 46 || // check position
            snake.getHeadY() < 4 || snake.getHeadY() > 46 ||
            snake.hitTail()) { // check if snake hits itself
            StdAudio.play("Death.wav"); // play sound effect
            snake.drawSnake(255, 0, 0); // draw dead snake
            drawEndScreen(); // draw end screen
            end = true; // enter end loop
            play = false; // exit play loop
            PennDraw.advance();
            return true;
        }
        return false;
    }
    
    /** Draws intro screens 
     * Parameters: none
     * Side Effects: draws intro screens and moves through sequence,
     *               takes in user name (initials)
     * Return: void
     */
    private static void drawIntro() {
        PennDraw.clear(0, 0, 0); // clear screen
        PennDraw.picture(25, 25, "Intro.png"); // draw intro screen 
        // draw updated highscore table
        PennDraw.setPenColor(168, 168, 168); 
        PennDraw.setFontSize(30);
        for (int i = 0; i < 5; i++) {
            PennDraw.text(18, 28 - 3.53 * i, scores.printName(i));
            if (scores.printName(i).length() != 0) {
                for (int j = 21; j < 30; j++) {
                    PennDraw.filledSquare(j, 28 - 3.53 * i, 0.25);
                }
            }
            PennDraw.text(33, 28 - 3.53 * i, scores.printScore(i));
        }
        PennDraw.advance();
        
        boolean next = true;
        while (next) { // move to next screen if key is typed
            if (PennDraw.hasNextKeyTyped()) {
                StdAudio.play("Continue.wav"); // play sound effect
                PennDraw.clear(0, 0, 0);
                PennDraw.nextKeyTyped();
                PennDraw.picture(25, 25, "Start.png"); // draw next screen
                PennDraw.advance();
                next = false; // exit loop and move to next loop
            }
        }
        
        while (!next) { // move to next screen if key is typed
            if (PennDraw.hasNextKeyTyped()) {
                StdAudio.play("Continue.wav"); // play sound effect
                PennDraw.nextKeyTyped();
                PennDraw.clear(0, 0, 0);
                PennDraw.picture(25, 25, "Name.png"); // draw next screen
                PennDraw.advance();
                next = true; // exit loop and move to next loop
            }
        }
        
        user = ""; // intialize user-defined name
        while (next) { // check for next key typed
            if (PennDraw.hasNextKeyTyped()) {
                char typed = PennDraw.nextKeyTyped();
                if (typed == '=') { // continue if '=' is typed
                    StdAudio.play("Continue.wav"); // sound effect
                    PennDraw.advance();
                    play = true; // begin play
                    return;
                } else {
                    if (typed == '-') { // clear string if '-' is typed
                        user = "";
                    } else if (user.length() < 2) { 
                        user += typed; // allow input up to two characters
                        user = user.toUpperCase(); 
                    }
                    PennDraw.clear(0, 0, 0);
                    PennDraw.picture(25, 25, "Name.png");
                    PennDraw.text(25, 28, user); // display user input text
                    PennDraw.advance();
                }
            }
        }
    }
    
    /** Draws gameboard 
     * Parameters: none
     * Side Effects: draws gameboard between while updating score
     * Return: void
     */
    private static void gameStart() {
        PennDraw.picture(25, 25, "Board.png"); // draw board
        // update text containing score with leading 0's
        String score = "";
        if (snake.getScore() < 10) {
            score += "000" + snake.getScore();
        } else if (snake.getScore() < 100) {
            score += "00" + snake.getScore();
        } else if (snake.getScore() < 1000) {
            score += "0" + snake.getScore();
        } else {
            score += snake.getScore();
        }
        PennDraw.setFontSize(22);
        PennDraw.text(44, 48, score);
        food = snake.getFood(); // draw food
        food.drawBit(255, 0, 0);
    }
    
    /** Draws end screen (gameover)
     * Parameters: none
     * Side Effects: draws end screen with updated highscore table
     * Return: void
     */
    private static void drawEndScreen() {
        scores.addScore(user, snake.getScore()); // add final score
        PennDraw.picture(25, 25, "EndScreen.png"); // draw end screen
        // update highscore table
        PennDraw.setPenColor(168, 168, 168);
        PennDraw.setFontSize(30);
        for (int i = 0; i < 5; i++) {
            PennDraw.text(18, 35.8 - 3.53 * i, scores.printName(i));
            if (scores.printName(i).length() != 0) {
                for (int j = 21; j < 30; j++) {
                    PennDraw.filledSquare(j, 35.8 - 3.53 * i, 0.25);
                }
            }
            PennDraw.text(33, 35.8 - 3.53 * i, scores.printScore(i));
        }
    }
    
    // main body function: 
    public static void main(String[] args) {
        // open game in new window
        PennDraw.setCanvasSize(700, 700);
        PennDraw.setXscale(0, 50);
        PennDraw.setYscale(0, 50);
        PennDraw.enableAnimation(10); // begin animation
        StdAudio.loop("Root.wav"); // play background music
        scores = new HighScores(); // initialize highscores
        drawIntro(); // begin intro sequence
        while (true) { // game begins
            while (play) { // playing
                PennDraw.clear(0, 0, 0);
                snake = new Snake();
                snake.generateFood();
                gameStart();
                PennDraw.advance();
                snakeRight(); // snake starts out moving right
            }
            while (end) { // gameover
                if (PennDraw.hasNextKeyTyped()) {
                    PennDraw.clear(0, 0, 0);
                    PennDraw.nextKeyTyped();
                    StdAudio.play("Start.wav"); // play sound effect
                    drawIntro(); // return to beginning
                    PennDraw.advance();
                    play = true; // enter play loop
                    end = false; // exit end loop
                }
            }
        }
    }
}