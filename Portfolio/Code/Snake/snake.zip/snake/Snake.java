/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java Snake
 * 
 * This program creates a Snake object based on an ArrayList 
 * of Bits. The snake has a head and tail and can move in all
 * four directions. A score is determined based on the size
 * of the snake and food is generated throughout the gameboard
 * for the snake to consume. 
 * 
 */

// import declarations
import java.util.ArrayList;

public class Snake implements SnakeInterface {
    private int x, y; // positions of head
    private Bit head, tail; // track head and tail of snake
    private Bit food; // random bit for snake to consume
    private ArrayList<Bit> snake; // create ArrayList of Bits
    
    // creates and draws a horizontal snake of size 3 
    public Snake() {
        snake = new ArrayList<Bit>(); // initialize snake
        // generate a random starting position on left side of screen
        x = (int) (10 + Math.random() * 20);
        y = (int) (4 + Math.random() * 43);
        // create three segments based on random head position
        head = new Bit(x, y);
        Bit body = new Bit(x - 1, y);
        tail = new Bit(x - 2, y);
        snake.add(tail);
        snake.add(body);
        snake.add(head);
        drawSnake(255, 255, 255);
    }
    
    /** Draws snake
     * Parameters: RGB values for the color of the snake
     * Side Effects: draws snake
     * Return: void
     */
    public void drawSnake(int r, int g, int b) {
        for (Bit bit : snake) {
            bit.drawBit(r, g, b);
        }
    }
    
    /** Moves snake to the right
     * Parameters: none
     * Side Effects: draws snake one bit to the right
     * Return: void
     */
    public void moveRight() {
        Bit newHead = new Bit(head.getX() + 1, y);
        head = newHead; 
        snake.add(head); // generate new head and replace old head
        // remove bit from the back of the snake if no bits are eaten
        if (eat(food) == false) {
            snake.remove(tail);
            tail = snake.get(0); // new tail
        }
        drawSnake(255, 255, 255);
        x++;
    }
    
    /** Moves snake to the left
     * Parameters: none
     * Side Effects: draws snake one bit to the left
     * Return: void
     */
    public void moveLeft() {
        Bit newHead = new Bit(head.getX() - 1, y);
        head = newHead;
        snake.add(head); // generate new head and replace old head
        // remove bit from the back of the snake if no bits are eaten
        if (eat(food) == false) {
            snake.remove(tail);
            tail = snake.get(0);
        }
        drawSnake(255, 255, 255);
        x--;
    }
    
    /** Moves snake upwards
     * Parameters: none
     * Side Effects: draws snake one bit up
     * Return: void
     */
    public void moveUp() {
        Bit newHead = new Bit(x, head.getY() + 1);
        head = newHead;
        snake.add(head); // generate new head and replace old head
        // remove bit from the back of the snake if no bits are eaten
        if (eat(food) == false) {
            snake.remove(tail);
            tail = snake.get(0);
        }
        drawSnake(255, 255, 255);
        y++;
    }
    
    /** Moves snake downwards
     * Parameters: none
     * Side Effects: draws snake one bit to down
     * Return: void
     */
    public void moveDown() {
        Bit newHead = new Bit(x, head.getY() - 1);
        head = newHead;
        snake.add(head); // generate new head and replace old head
        // remove bit from the back of the snake if no bits are eaten
        if (eat(food) == false) { // grow by one bit if snake is eating 
            snake.remove(tail);
            tail = snake.get(0);
        }
        drawSnake(255, 255, 255);
        y--;
    }
    
    /** Get method for x position of head 
     * Parameters: none
     * Return: x position
     */
    public int getHeadX() {
        return x;
    }
    
    /** Get method for y position of head 
     * Parameters: none
     * Return: x position
     */
    public int getHeadY() {
        return y;
    }
    
    /** Gets a score based on length of snake
     * Parameters: none
     * Return: get method for size of snake ArrayList
     */
    public int getScore() {
        return snake.size();
    }
    
    /** Checks if snake hits itself
     * Parameters: none
     * Return: boolean (true if hit)
     */
    public boolean hitTail() {
        // compare head position with positions of each bit in the snake
        for (int i = 0; i < snake.size() - 1; i++) {
            if (getHeadX() == snake.get(i).getX() &&
                getHeadY() == snake.get(i).getY()) {
                return true;
            }
        }
        return false;
    }
    
    /** Checks if other randomly generated bits overlap with the snake
     * Parameters: bit being compared
     * Return: boolean (true if bits overlap)
     */
    public boolean overlap(Bit food) {
        // compare bit position with positions of each bit in the snake
        for (Bit bit : snake) {
            if (food.getX() == bit.getX() && food.getY() == bit.getY()) {
                return true;
            }
        }
        return false;
    }
    
    /** Checks if food is being eaten
     * Parameters: bit being "eaten"
     * Side Effects: plays sound effect
     * Return: boolean (true if bit is eaten)
     */
    public boolean eat(Bit food) {
        // compare head positions with food positions
        if (head.getX() == food.getX() && head.getY() == food.getY()) {
            StdAudio.play("Eat.wav");
            return true;
        }
        return false;
    }
    
    /** Generates random "food" bits
     * Parameters: none
     * Side Effects: generates a random bit
     * Return: void
     */
    public void generateFood() {
        food = Bit.random();
        // generate a new position if position overlaps with snake
        while (overlap(food)) { 
            food = Bit.random();
        }
    }
    
    /** Get method for "food" bit
     * Parameters: none
     * Return: food Bit
     */
    public Bit getFood() {
        return food;
    }
}