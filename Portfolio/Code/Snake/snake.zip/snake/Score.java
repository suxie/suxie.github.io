/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java Score
 * 
 * This program creates a Score object that contains the name
 * entered by each user at the start of the game and the final
 * score they had before they died. 
 * 
 */

public class Score implements ScoreInterface {
    private String name; // user-inputted intials
    private int score; // final score
    
    // creates a new HighScore Object based on user name and score
    public Score(String name, int score) {
        this.name = name;
        this.score = score;
    }
    
    /** Get method for score 
     * Parameters: none
     * Return: int score
     */
    public int getScore() {
        return score;
    }
    
    /** Get method for name 
     * Parameters: none
     * Return: String name
     */
    public String getName() {
        return name;
    }
}