/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java HighScoresInterface
 * 
 * This file creates an interface to be implemented in creating
 * a list of scores (used in HighScores.java).
 * 
 */

public interface HighScoresInterface {
    
    /** Adds a score to the list of highscores if the score is 
     *  a new high score (within the top five scores in the game)
     * Parameters: name (String) and highscore (int) to be added 
     *             to the highscore list
     * Side Effects: adds score to highscore list
     * Return: void
     */
    void addScore(String name, int highscore);
    
    /** Returns the score in each HighScore to be printed
     * Parameters: index i where the score is located
     * Return: String representation of the score with leading 0's
     */
    String printScore(int i);
    
    /** Returns the name in each HighScore to be printed
     * Parameters: index i where the name is located
     * Return: String containing initials
     */
    String printName(int i);
}