/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java BitInterface
 * 
 * This file creates an interface to be implemented in creating a 
 * bit-like object for drawing (used in Bit.java).
 * 
 */

public interface BitInterface {
    
    /** Draws bit
     * Parameters: RGB values for the color of the bit
     * Side Effects: draws bit
     * Return: void
     */
    void drawBit(int r, int g, int b);
    
    /** Get method for x value 
     * Parameters: none
     * Return: x position
     */
    int getX();
    
    /** Get method for y value
     * Parameters: none
     * Return: y position
     */
    int getY();
    
    
}