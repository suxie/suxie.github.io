/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java Bit
 * 
 * This program creates a Bit object that draws a square at a 
 * point specified by the user. There are functions to draw 
 * the Bit as well as others to get its x and y positions. 
 * The program can also generate a random x and y position on
 * the board and create a Bit there. 
 * 
 */

public class Bit implements BitInterface {
    private int x, y; // position variables
    
    // creates a new Bit based on a user-defined x and y position
    public Bit(int x, int y) { // store values of x and y
        this.x = x;
        this.y = y;
    }
    
    /** Draws bit
     * Parameters: RGB values for the color of the bit
     * Side Effects: draws bit
     * Return: void
     */
    public void drawBit(int r, int g, int b) {
        PennDraw.setPenColor(r, g, b);
        PennDraw.filledSquare(x, y, 0.4);
    }
    
    /** Get method for x value 
     * Parameters: none
     * Return: x position
     */
    public int getX() {
        return x;
    }
    
    /** Get method for y value
     * Parameters: none
     * Return: y position
     */
    public int getY() {
        return y;
    }
    
    /** Generates random bit
     * Parameters: none - static method
     * Return: random Bit
     */
    public static Bit random() {
        int x = (int) (4 + Math.random() * 43);
        int y = (int) (4 + Math.random() * 43);
        return new Bit(x, y);
    }
    
    /** TEST CASES: 
      * public static void main(String[] args) {
      *     PennDraw.clear(0, 0, 0);
      *     PennDraw.setXscale(0, 50);
      *     PennDraw.setYscale(0, 50);
      *     PennDraw.setPenRadius(0.025);
      *     PennDraw.setPenColor(255, 255, 255);
      *     PennDraw.point(25, 20);
      *     PennDraw.filledPolygon(24.75, 24.75, 24.75, 26, 
      *                            23.5, 26, 23.5, 24.75);
      *     Bit test = new Bit(20, 25);
      * }
      */
}