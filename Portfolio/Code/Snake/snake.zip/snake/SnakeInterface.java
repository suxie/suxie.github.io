/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java SnakeInterface
 * 
 * This file creates an interface for a snake object in a classic
 * snake game (used in Snake.java).
 * 
 */

public interface SnakeInterface {
    /** Draws snake
     * Parameters: RGB values for the color of the snake
     * Side Effects: draws snake
     * Return: void
     */
    void drawSnake(int r, int g, int b);
    
    /** Moves snake to the right
     * Parameters: none
     * Side Effects: draws snake one bit to the right
     * Return: void
     */
    void moveRight();
    
    /** Moves snake to the left
     * Parameters: none
     * Side Effects: draws snake one bit to the left
     * Return: void
     */
    void moveLeft();
    
    /** Moves snake upwards
     * Parameters: none
     * Side Effects: draws snake one bit up
     * Return: void
     */
    void moveUp();
    
    /** Moves snake downwards
     * Parameters: none
     * Side Effects: draws snake one bit to down
     * Return: void
     */
    void moveDown();
    
    /** Get method for x position of head 
     * Parameters: none
     * Return: x position
     */
    int getHeadX();
    
    /** Get method for y position of head 
     * Parameters: none
     * Return: x position
     */
    int getHeadY();
    
    /** Gets a score based on length of snake
     * Parameters: none
     * Return: get method for size of snake ArrayList
     */
    int getScore();
    
    /** Checks if snake hits itself
     * Parameters: none
     * Return: boolean (true if hit)
     */
    boolean hitTail();
    
    /** Checks if other randomly generated bits overlap with the snake
     * Parameters: bit being compared
     * Return: boolean (true if bits overlap)
     */
    boolean overlap(Bit food);
    
    /** Checks if food is being eaten
     * Parameters: bit being "eaten"
     * Side Effects: plays sound effect
     * Return: boolean (true if bit is eaten)
     */
    boolean eat(Bit food);
    
    /** Generates random "food" bits
     * Parameters: none
     * Side Effects: generates a random bit
     * Return: void
     */
    void generateFood();
    
    /** Get method for "food" bit
     * Parameters: none
     * Return: food Bit
     */
    Bit getFood();
    
}