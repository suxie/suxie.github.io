/*
 * Name: Susan Xie
 * PennKey: susanxie
 * Recitation: 207
 * 
 * Execution: java ScoreInterface
 * 
 * This file creates an interface for getting an int and String 
 * component of an object (used in Score.java).
 * 
 */

public interface ScoreInterface {
    
    /** Get method for score 
     * Parameters: none
     * Return: int score
     */
    int getScore();
    
    /** Get method for name 
     * Parameters: none
     * Return: String name
     */
    String getName();
}